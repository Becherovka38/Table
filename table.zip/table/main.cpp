#include "mainwindow.h"
#include <QStyle>
#include "QStyleFactory"

#include <QApplication>

void os(QApplication &a);

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    os(a);
    MainWindow w;
    w.show();
    return a.exec();
}

void os(QApplication &a){
        a.setStyle(QStyleFactory::create("Fusion"));
}
