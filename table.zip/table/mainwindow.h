#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtCharts/QPieSeries>
#include <QtCharts/QChartView>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_TableImport_clicked();

    void on_AddCargo_clicked();

    void on_TableDelete_clicked();

    void on_TableExport_clicked();

    void on_addEnter_clicked();

    void on_Edit_clicked();

    void on_errorAccept_clicked();

    void on_tableWidget_cellChanged(int row, int column);

    void on_addClose_clicked();

    void on_showChart_clicked();

    void on_updateChart_clicked();

    void onChartDialogClosed();

private:
    Ui::MainWindow *ui;
    QPieSeries *series;  // Серии для диаграммы
    QChart *chart;       // График
    QChartView *chartView; // Виджет для отображения графика
    QDialog *chartDialog;

    void updatePieChart();         // Метод обновления диаграммы
    bool isChartShown = false;  // Флаг видимости диаграммы
};
#endif // MAINWINDOW_H
