#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QFileDialog"
#include "QScreen"
#include "QFile"
#include "QTextStream"
#include "QMessageBox"
#include "./checkers.h"
#include "QInputDialog"
#include <QtCharts/QPieSlice>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // настройка окон
    ui->add->setWindowFlags(Qt::Dialog | Qt::WindowMinimizeButtonHint);
    ui->add->setWindowTitle("Добавление поставки");

    ui->error->setWindowFlags(Qt::Dialog);
    ui->error->setWindowTitle("Ошибка!");
    ui->error->setWindowModality(Qt::WindowModal);

    ui->edit->setWindowFlags(Qt::Dialog);
    ui->edit->setWindowTitle("Редактирование таблицы");

    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    // Инициализация диаграммы
    series = new QPieSeries();
    chart = new QChart();
    chartView = new QChartView(chart);

    // Настройка диаграммы
    chart->addSeries(series);
    chart->setTitle("Распределение товаров по поставщикам");
    chart->legend()->setVisible(true);
    chart->legend()->setAlignment(Qt::AlignRight);
    chart->setAnimationOptions(QChart::AllAnimations);
    chartView->setRenderHint(QPainter::Antialiasing);
    chartView->setMinimumSize(600, 400);

    // Создаем диалоговое окно
    chartDialog = new QDialog(this);
    chartDialog->setWindowTitle("Диаграмма поставщиков");
    QVBoxLayout *layout = new QVBoxLayout(chartDialog);
    layout->addWidget(chartView);
    chartDialog->setLayout(layout);
    chartDialog->resize(650, 450);

    // Подключаем сигнал закрытия окна
    connect(chartDialog, &QDialog::finished, this, &MainWindow::onChartDialogClosed);

    connect(ui->ShowChart, &QPushButton::clicked, this, &MainWindow::on_showChart_clicked);
}

MainWindow::~MainWindow()
{
    delete chartDialog;
    delete ui;
}

void MainWindow::on_AddCargo_clicked()
{
    // настройка виджетов (пока оставить)

    /*
    QWidget *window = new QWidget();
    window->setWindowTitle("Добавление поставки");
    window->setFixedSize(400,200);
    window->mapFromParent(m_table->pos());

    QTextEdit *text = new QTextEdit(window);

    QPushButton *button = new QPushButton(window);
    button->setText("Ввод");
    button->setFixedSize(80,30);

    QLabel *label = new QLabel(window);
    label->setStyleSheet("font: 13pt;");
    label->setText("Введите название товара");

    QGridLayout *layout = new QGridLayout(window);
    layout->setAlignment(Qt::AlignTop);
    layout->addWidget(label,0,0);
    layout->addWidget(button,0,1);
    layout->addWidget(text,1,0);
    window->show();

    while(true){
        if(button->isDown()){
            label->setText("абв");
        }
    }
    */

    QRect screenGeometry = QApplication::primaryScreen()->geometry();
    int x = (screenGeometry.width() / 2.5);
    int y = (screenGeometry.height() / 2.5);
    ui->add->move(x,y);
    ui->add->show();

    ui->tableWidget->insertRow( ui->tableWidget->rowCount() );
}


void MainWindow::on_TableDelete_clicked()
{
    ui->tableWidget->removeRow(ui->tableWidget->rowCount()-1);
}

void MainWindow::on_TableImport_clicked()
{
    QString path = QFileDialog::getOpenFileName(this,QString("Импорт данных"),"",QString("txt (*.txt);;Все файлы (*)"));
    if(path.isEmpty())
        return;
    else{
        QFile file(path);
        if(!file.open(QIODevice::ReadOnly)){

            return;
        }
        else{
            QTextStream in( &file );
            ui->tableWidget->setRowCount(in.readLine().toInt());

            for( int i = 0; i < ui->tableWidget->rowCount(); i++ ){
                for(int j = 0; j < ui->tableWidget->columnCount();j++){
                    QTableWidgetItem *item = new QTableWidgetItem;
                    item->setText(in.readLine());
                    ui->tableWidget->setItem(i,j,item);
                }
            }
        }
        file.close();
    }
}

void MainWindow::on_TableExport_clicked()
{
    QString path = QFileDialog::getSaveFileName(this,QString("Экспорт данных"),"",QString("txt (*.txt);;Все файлы (*)"));
    if(path.isEmpty())
        return;
    else{
        QFile file(path);
        if(!file.open(QIODevice::WriteOnly)){

            return;
        }
        else{
            QTextStream out( &file );
            out << ui->tableWidget->rowCount() << '\n';
            for( int i = 0; i < ui->tableWidget->rowCount(); i++ ){
                for(int j =0; j < ui->tableWidget->columnCount();j++){
                    QTableWidgetItem* item = ui->tableWidget->item(i,j);
                    if(!item || item->text().isEmpty()){
                        out << "";
                    }
                    else{
                        out << item->text();
                    }
                    out << '\n';
                }
            }
        }
        file.close();
    }
}


void MainWindow::on_addEnter_clicked()
{
    QWidget *error = ui->error;
    QTableWidget *table = ui->tableWidget;
    QLabel *label = ui->addLabel;
    QTextEdit *textedit = ui->addTextEdit;


    QRect screenGeometry = QApplication::primaryScreen()->geometry();
    int x = (screenGeometry.width() / 2.5);
    int y = (screenGeometry.height() / 2.5);
    error->move(x,y);


    if(label->text() == "Введите название поставки"){
        if(!Checkers::StringCheck(textedit->toPlainText())){
            error->show();
        }
        else{
            QTableWidgetItem* item = new QTableWidgetItem(textedit->toPlainText());
            table->setItem(table->rowCount()-1,0,item);
            label->setText("Введите название поставщика");
        }
    }
    else if(label->text() == "Введите название поставщика"){
        if(!Checkers::StringCheck(textedit->toPlainText())){
            error->show();
        }
        else{
            QTableWidgetItem* item = new QTableWidgetItem(textedit->toPlainText());
            table->setItem(table->rowCount()-1,1,item);
            label->setText("Введите дату поставки");
        }
    }
    else if(label->text() == "Введите дату поставки"){
        if(!Checkers::IntCheck(textedit->toPlainText(),1)){
            error->show();
        }
        else{
            QTableWidgetItem* item = new QTableWidgetItem(textedit->toPlainText());
            table->setItem(table->rowCount()-1,2,item);
            label->setText("Введите цену товара");
        }
    }
    else if(label->text() == "Введите цену товара"){
        if(!Checkers::IntCheck(textedit->toPlainText())){
            error->show();
        }
        else{
            QTableWidgetItem* item = new QTableWidgetItem(textedit->toPlainText());
            table->setItem(table->rowCount()-1,3,item);
            label->setText("Введите артикул товара");
        }
    }
    else if(label->text() == "Введите артикул товара"){
        if(!Checkers::IntCheck(textedit->toPlainText())){
            error->show();
        }
        else{
            QTableWidgetItem* item = new QTableWidgetItem(textedit->toPlainText());
            table->setItem(table->rowCount()-1,4,item);
            label->setText("Введите цвет товара");
        }
    }
    else if(label->text() == "Введите цвет товара"){
        if(!Checkers::StringCheck(textedit->toPlainText())){
            error->show();
        }
        else{
            QTableWidgetItem* item = new QTableWidgetItem(textedit->toPlainText());
            table->setItem(table->rowCount()-1,5,item);
            label->setText("Введите размер товара");
        }
    }
    else if(label->text() == "Введите размер товара"){
        if(!Checkers::StringCheck(textedit->toPlainText())){
            error->show();
        }
        else{
            QTableWidgetItem* item = new QTableWidgetItem(textedit->toPlainText());
            table->setItem(table->rowCount()-1,6,item);
            ui->add->close();
        }
    }
    textedit->clear();
}


void MainWindow::on_Edit_clicked()
{
    QRect screenGeometry = QApplication::primaryScreen()->geometry();
    int x = (screenGeometry.width() / 2.5);
    int y = (screenGeometry.height() / 2.5);
    ui->edit->move(x,y);

    // пока не работает
    /*
    if(ui->editFast->checkState() == Qt::Checked){
        for(int i{0};i<table->rowCount();i++){
            for(int j{0};j<table->columnCount();j++){
                table->item(i,j)->setFlags(table->item(i,j)->flags() | Qt::ItemIsEditable);
            }
        }
    }
    else if(ui->editFast->checkState() == Qt::Unchecked){
        for(int i{0};i<table->rowCount();i++){
            for(int j{0};j<table->columnCount();j++){
                table->item(i,j)->setFlags(table->item(i,j)->flags() & ~(Qt::ItemIsEditable));
            }
        }
    }
    */
    ui->edit->show();
}


void MainWindow::on_errorAccept_clicked()
{
    ui->error->close();
}


void MainWindow::on_tableWidget_cellChanged(int row, int column)
{
    QCursor *cursor = new QCursor();

    QWidget *error = ui->error;
    QTableWidgetItem *item = ui->tableWidget->item(row,column);

    QRect screenGeometry = QApplication::primaryScreen()->geometry();
    int x = (screenGeometry.width() / 2.5);
    int y = (screenGeometry.height() / 2.5);
    error->move(x,y);


    switch(column){
    case 0:
        if(!Checkers::StringCheck(item->text())){
            item->setText("");
            cursor->setPos(x+100,y+20);
            error->show();
        }
    }
    // case 1,2,3,...
}


void MainWindow::on_addClose_clicked()
{
    ui->add->close();
}

void MainWindow::on_showChart_clicked()
{
    updatePieChart();  // Обновляем данные перед показом

    if (chartDialog->isVisible()) {
        chartDialog->hide();
        ui->ShowChart->setText("Показать диаграмму");
    } else {
        chartDialog->show();
        ui->ShowChart->setText("Скрыть диаграмму");
    }
}

void MainWindow::onChartDialogClosed()
{
    ui->ShowChart->setText("Диаграммы");
}

void MainWindow::updatePieChart()
{
    series->clear();  // Очищаем старые данные

    // Собираем статистику по поставщикам
    QMap<QString, int> suppliers;
    for (int i = 0; i < ui->tableWidget->rowCount(); ++i) {
        QTableWidgetItem *item = ui->tableWidget->item(i, 1);  // Колонка с поставщиками
        if (item && !item->text().isEmpty()) {
            suppliers[item->text()]++;
        }
    }

    // Добавляем данные в диаграмму
    for (auto it = suppliers.begin(); it != suppliers.end(); ++it) {
        QPieSlice *slice = series->append(it.key(), it.value());
        slice->setLabelVisible(true);
        slice->setLabel(QString("%1 (%2 шт.)").arg(it.key()).arg(it.value()));
    }

    // Обновляем заголовок
    chart->setTitle(QString("Товары по поставщикам (всего: %1)").arg(ui->tableWidget->rowCount()));
}

void MainWindow::on_updateChart_clicked()
{
    if (isChartShown) {
        updatePieChart();
    }
}
