#ifndef CHECKERS_H
#define CHECKERS_H
#include "QString"

class Checkers
{
public:
    // конструктор

    Checkers();

    // методы

    static bool IntCheck(QString string, int mode = 0);

    static bool StringCheck(QString string);
};

#endif // CHECKERS_H
