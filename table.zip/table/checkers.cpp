#include "checkers.h"

Checkers::Checkers() {}

bool Checkers::IntCheck(QString string, int mode){
    QString dict = ".";

    // режим определяет тип проверки (в разработке)
    // режимы: 0 - обычная проверка, 1 - проверка даты

    if(string.size() == 0){
        return false;
    }

    switch(mode){
    case 0:
        for(int i{0};i < string.size();i++){
            if(!string[i].isDigit()){
                return false;
            }
        }
        break;
    case 1:
        for(int i{0};i < string.size();i++){
            if(!(string[i].isDigit() or dict.contains(string[i]))){
                return false;
            }
        }
        break;
    }
    return true;
}

// в разработке: проверка на размер
bool Checkers::StringCheck(QString string){
    if(string.size() == 0){
        return false;
    }

    for(int i{0};i < string.size();i++){
        if(string[i].isDigit()){
            return false;
        }
    }
    return true;
}
